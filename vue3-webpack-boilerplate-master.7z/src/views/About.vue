<template>
  <div>
    About Page
  </div>
</template>

<script lang="ts">
export default {
  name: "About"
}
</script>

<style>

</style>
